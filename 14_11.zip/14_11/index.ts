import express, { Express, Request, Response } from 'express'
import * as path from 'path'
import { apiRouter } from './api-router'
import { PrismaClient } from '@prisma/client'
import { MongoClient } from 'mongodb'

const mongoUrl = "mongodb://172.25.160.1:27017/baza"

const prisma = new PrismaClient()

const port = 3000
const app = express()

app.use(express.static(path.join(__dirname, '/public')))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use('/api', apiRouter)

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/homepage.html'))
})

app.get('/kontakt', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/contact.html'))
})

app.post('/kontakt', async(req, res) => { 
    try {
        const db = await MongoClient.connect(mongoUrl)
        const mydb = db.db("baza")
        console.log("Database created")
        await db.close()
    } catch (e){
        throw e
    }
    res.redirect('/')
})

app.listen(3000, () => {
    console.log(`App listening on port: ${port}`)
})
