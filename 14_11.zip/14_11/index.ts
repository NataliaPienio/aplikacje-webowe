import express, { Express, Request, Response } from 'express'
import * as path from 'path'
import { apiRouter } from './api-router'
import { MongoClient } from 'mongodb'

const mongoUrl = "mongodb+srv://nataliapienio:nataliapienio123@nataliap.jwzyamf.mongodb.net/?retryWrites=true&w=majority"

const port = 3000
const app = express()

app.use(express.static(path.join(__dirname, '/public')))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use('/api', apiRouter)

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/homepage.html'))
})

app.get('/kontakt', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/contact.html'))
})

app.post('/kontakt', async(req, res) => { 
    try {
        const db = await MongoClient.connect(mongoUrl)
        const dbo = db.db("baza")
        const myObj = { name: req.body.name, email: req.body.email, temat: req.body.topic, wiadomosc: req.body.message}
        try{
            await (await dbo.createCollection("contact")).insertOne(myObj)
        }catch (e){
            throw e
        }
        await db.close()
    } catch (e){
        throw e
    }
    res.redirect('/')
})

app.listen(3000, () => {
    console.log(`App listening on port: ${port}`)
})
