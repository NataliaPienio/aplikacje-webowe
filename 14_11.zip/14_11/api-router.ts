//import { Prisma, PrismaClient } from '@prisma/client'
import express, { Express, Request, Response, text } from 'express'
import { Collection, MongoClient } from 'mongodb'
const router = express.Router()

//const prisma = new PrismaClient()

router.get('/', (req, res) => {
    const apiLinks = {
        "students": "/api/students",
        "subjects": "/api/subjects"
    }

    res.send(apiLinks)
})

/*router.get('/students', async(req, res) => { 
    const result = await prisma.students.findMany()
    res.send(result)
})
router.get('/students/:id', async(req, res) => { 
    const idStudent = req.body.id
    const result = await prisma.students.findMany({
        where:{id:parseInt(idStudent)}
    })
    res.send(result)
})

router.get('/subjects', async(req, res) => { 
    const result = await prisma.subjects.findMany()
    res.send(result)
})
router.get('/subjects/:id', async(req, res) => { 
    const idSubject = req.body.id
    const result = await prisma.subjects.findMany({
        where:{id:parseInt(idSubject)}
    })
    res.send(result)
})*/
router.get('/messages', async(req, res) => { 
    const result = await dbo.collection("contact").find(myObj).toArray()
    res.send(result)
})


export { router as apiRouter }