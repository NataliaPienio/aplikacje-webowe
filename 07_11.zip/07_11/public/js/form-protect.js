// Zabezpieczenie przed wysłaniem formularza
document.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault();
    alert('Nie można wysłać wiadomości');
  });
  