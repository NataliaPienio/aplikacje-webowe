import express, { Express, Request, Response } from 'express'
import * as path from 'path'
import { apiRouter } from './api-router'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const port = 3000
const app = express()

app.use(express.static(path.join(__dirname, '/public')))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use('/api', apiRouter)

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/homepage.html'))
})

app.get('/kontakt', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/contact.html'))
})

app.post('/kontakt', async(req, res) => { 
    await prisma.wiadomosc.create({
        data: { 
            imie: req.body.name,
            email: req.body.email,
            temat: req.body.topic,
            wiadomosc: req.body.message
        }
    })
    res.redirect('/')
})

app.listen(3000, () => {
    console.log(`App listening on port: ${port}`)
})
