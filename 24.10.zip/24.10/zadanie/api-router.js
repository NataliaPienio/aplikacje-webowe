"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiRouter = void 0;
const express_1 = __importDefault(require("express"));
const mysql_1 = require("mysql");
const router = express_1.default.Router();
exports.apiRouter = router;
const getTableData = (tableName, id = "") => {
    let sqlQuery = `SELECT * FROM ${tableName}`;
    if (id != "")
        sqlQuery += ` WHERE id = ${id}`;
    const connection = (0, mysql_1.createConnection)({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' });
    connection.connect(err => {
        if (err)
            throw err;
        connection.query(sqlQuery, (err, result) => {
            if (err)
                throw err;
        });
    });
};
router.get('/', (req, res) => {
    const apiLinks = {
        "students": "/api/students",
        "subjects": "/api/subjects"
    };
    res.send(apiLinks);
});
router.get('/students', (req, res) => {
    let sqlQuery = 'SELECT * FROM students';
    const connection = (0, mysql_1.createConnection)({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' });
    connection.connect(err => {
        if (err)
            throw err;
        connection.query(sqlQuery, (err, result) => {
            if (err)
                throw err;
            res.send(result);
        });
    });
});
router.get('/students/:id', (req, res) => {
    let sqlQuery = `SELECT * FROM students WHERE id = ${req.params.id}`;
    const connection = (0, mysql_1.createConnection)({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' });
    connection.connect(err => {
        if (err)
            throw err;
        connection.query(sqlQuery, (err, result) => {
            if (err)
                throw err;
            res.send(result);
        });
    });
});
router.get('/subjects', (req, res) => {
    let sqlQuery = 'SELECT * FROM subjects';
    const connection = (0, mysql_1.createConnection)({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' });
    connection.connect(err => {
        if (err)
            throw err;
        connection.query(sqlQuery, (err, result) => {
            if (err)
                throw err;
            res.send(result);
        });
    });
});
router.get('/subjects/:id', (req, res) => {
    let sqlQuery = `SELECT * FROM subjects WHERE id = ${req.params.id}`;
    const connection = (0, mysql_1.createConnection)({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' });
    connection.connect(err => {
        if (err)
            throw err;
        connection.query(sqlQuery, (err, result) => {
            if (err)
                throw err;
            res.send(result);
        });
    });
});
