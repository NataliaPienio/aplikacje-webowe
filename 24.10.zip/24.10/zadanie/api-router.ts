import express, { Express, Request, Response, text } from 'express'
import { createConnection, Connection, MysqlError } from 'mysql'
const router = express.Router()

const getTableData: any = (tableName: string, id: string = "") => {
    let sqlQuery = `SELECT * FROM ${tableName}`
    if (id != "") sqlQuery += ` WHERE id = ${id}`

    const connection = createConnection({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' })
    connection.connect(err => {
        if (err) throw err

        connection.query(sqlQuery, (err, result) => {
            if (err) throw err
        })
    })
}

router.get('/', (req, res) => {
    const apiLinks = {
        "students": "/api/students",
        "subjects": "/api/subjects"
    }

    res.send(apiLinks)
})

router.get('/students', (req, res) => { 
    let sqlQuery = 'SELECT * FROM students'

    const connection = createConnection({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' })
    connection.connect(err => {
        if (err) throw err

        connection.query(sqlQuery, (err, result) => {
            if (err) throw err
            res.send(result)
        })
    })
})
router.get('/students/:id', (req, res) => { 
    let sqlQuery = `SELECT * FROM students WHERE id = ${req.params.id}`

    const connection = createConnection({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' })
    connection.connect(err => {
        if (err) throw err

        connection.query(sqlQuery, (err, result) => {
            if (err) throw err
            res.send(result)
        })
    }) 
})

router.get('/subjects', (req, res) => { 
    let sqlQuery = 'SELECT * FROM subjects'

    const connection = createConnection({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' })
    connection.connect(err => {
        if (err) throw err

        connection.query(sqlQuery, (err, result) => {
            if (err) throw err
            res.send(result)
        })
    })    
})
router.get('/subjects/:id', (req, res) => { 
    let sqlQuery = `SELECT * FROM subjects WHERE id = ${req.params.id}`

    const connection = createConnection({ host: '172.22.48.1', user: 'root', password: '', database: 'paw_jw' })
    connection.connect(err => {
        if (err) throw err

        connection.query(sqlQuery, (err, result) => {
            if (err) throw err
            res.send(result)
        })
    })
})



export { router as apiRouter }